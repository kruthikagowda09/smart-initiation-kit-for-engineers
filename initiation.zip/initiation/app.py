from flask import Flask, render_template, request, jsonify
import requests, joblib, numpy as np, sqlite3, os

app = Flask(__name__)

# ==========================================================
# ⚙️ Load Trained Model and Label Encoder
# ==========================================================
model = joblib.load("crop_predictor.pkl")
label_encoder = joblib.load("crop_label_encoder.pkl")

# ==========================================================
# 🗄️ Database Setup
# ==========================================================
DB_PATH = "crop_data.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS crop_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            moisture REAL,
            temperature REAL,
            humidity REAL,
            waterlevel REAL
        )
    """)
    conn.commit()
    conn.close()

init_db()

# ==========================================================
# 🌤️ Environmental Condition Helper
# ==========================================================
def check_condition(value, low, high):
    if value < low:
        return "Low"
    elif value > high:
        return "High"
    else:
        return "Normal"

# ==========================================================
# 🏠 Home Route
# ==========================================================
@app.route("/")
def home():
    return render_template("index.html")

# ==========================================================
# 🌾 1️⃣ Fetch Live Data from API and Save to DB
# ==========================================================
@app.route("/fetch_live")
def fetch_live():
    url = "https://aislyntech.com/Api/z-get"
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        return jsonify({"error": f"API error: {str(e)}"})

    if "data" not in data or not data["data"]:
        return jsonify({"error": "No data found in API response"})

    record = data["data"][0]

    try:
        moisture = float(record["moisture"])
        temperature = float(record["temperature"])
        humidity = float(record["humidity"])
        waterlevel = float(record["waterlevel"])
    except (KeyError, ValueError) as e:
        return jsonify({"error": f"Invalid or missing data: {e}"})

    # Save to DB
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO crop_data (moisture, temperature, humidity, waterlevel)
        VALUES (?, ?, ?, ?)
    """, (moisture, temperature, humidity, waterlevel))
    conn.commit()
    conn.close()

    print(f"✅ New Data → M:{moisture}, T:{temperature}, H:{humidity}, W:{waterlevel}")

    return jsonify({
        "message": "Live data fetched and stored successfully",
        "data": {
            "moisture": moisture,
            "temperature": temperature,
            "humidity": humidity,
            "waterlevel": waterlevel
        }
    })

# ==========================================================
# 🌱 2️⃣ Predict Crop using Latest Data
# ==========================================================
@app.route("/predict_crop")
def predict_crop():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT moisture, temperature, humidity, waterlevel FROM crop_data ORDER BY id DESC LIMIT 1")
    latest = c.fetchone()
    conn.close()

    if not latest:
        return jsonify({"error": "No live data available for prediction"})

    # Prepare sample
    sample = np.array([list(latest)])
    probs = model.predict_proba(sample)[0]
    sorted_indices = np.argsort(probs)[::-1]

    main_crop = label_encoder.inverse_transform([sorted_indices[0]])[0]
    alt_crops = label_encoder.inverse_transform(sorted_indices[1:3])

    moisture, temperature, humidity, waterlevel = latest

    env = {
        "Temperature": f"{temperature}°C → {check_condition(temperature, 20, 35)}",
        "Moisture": f"{moisture}% → {check_condition(moisture, 40, 70)}",
        "Humidity": f"{humidity}% → {check_condition(humidity, 30, 80)}",
        "Water Level": f"{waterlevel} → {check_condition(waterlevel, 20, 60)}"
    }

    return jsonify({
        "main_crop": main_crop,
        "alt_crops": alt_crops.tolist(),
        "env": env
    })

# ==========================================================
# 📋 3️⃣ View Database (Latest First)
# ==========================================================
@app.route("/view_db")
def view_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM crop_data ORDER BY id DESC")  # latest first
    rows = c.fetchall()
    conn.close()

    data = [
        {
            "id": row[0],
            "moisture": row[1],
            "temperature": row[2],
            "humidity": row[3],
            "waterlevel": row[4]
        } for row in rows
    ]

    return jsonify(data)

# ==========================================================
# 🧹 4️⃣ Clear Database
# ==========================================================
@app.route("/clear_db")
def clear_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM crop_data")
    conn.commit()
    conn.close()
    return jsonify({"message": "Database cleared successfully"})

# ==========================================================
# 🚀 Run App
# ==========================================================
if __name__ == "__main__":
    app.run(debug=True)
