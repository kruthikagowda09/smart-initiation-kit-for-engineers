import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib

# 1️⃣ Load dataset
# Make sure your CSV has these columns: moisture, temperature, humidity, waterlevel, crop
df = pd.read_csv("updated_dataset.csv")  # replace with your dataset file

# 2️⃣ Extract features and labels
X = df[["moisture", "temperature", "humidity", "waterlevel"]]
y = df["Crop"]

# 3️⃣ Encode labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# 4️⃣ Split data for training and testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42
)

# 5️⃣ Train model (Random Forest)
model = RandomForestClassifier(
    n_estimators=200, 
    max_depth=10, 
    random_state=42
)
model.fit(X_train, y_train)

### 6️⃣ Evaluate model
##y_pred = model.predict(X_test)
##accuracy = accuracy_score(y_test, y_pred)
##print(f"✅ Model Training Complete!")
##print(f"🎯 Accuracy: {accuracy * 100:.2f}%")
##print("\n📊 Classification Report:")
##print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))

# 7️⃣ Save model and encoder
joblib.dump(model, "crop_predictor.pkl")
joblib.dump(label_encoder, "crop_label_encoder.pkl")

print("\n💾 Model and encoder saved successfully!")
