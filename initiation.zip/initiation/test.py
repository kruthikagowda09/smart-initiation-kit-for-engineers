### crop_prediction_live_final.py
##
##import requests
##import joblib
##import numpy as np
##import pandas as pd
##
### =====================================================
### ⚙️ Load Model and Encoder
### =====================================================
##model = joblib.load("crop_predictor.pkl")
##label_encoder = joblib.load("crop_label_encoder.pkl")
##
### =====================================================
### 🌐 Fetch Live Data from API
### =====================================================
##url = "https://aislyntech.com/Api/z-get.php"
##response = requests.get(url)
##
##if response.status_code != 200:
##    print("❌ Failed to fetch data from API.")
##    exit()
##
##data = response.json()
##
### =====================================================
### 📦 Extract Record
### =====================================================
##if "data" in data and len(data["data"]) > 0:
##    record = data["data"][0]
##else:
##    print("⚠️ No data found in API response.")
##    exit()
##
### =====================================================
### 🧮 Extract Features
### =====================================================
##try:
##    # This field exists in the API but was NOT used for training
##    d_temperature = float(record["d_temperature"])
##
##    # These are the features used during model training
##    moisture = float(record["moisture"])
##    temperature = float(record["temperature"])
##    humidity = float(record["humidity"])
##    waterlevel = float(record["waterlevel"])
##
##except KeyError as e:
##    print(f"⚠️ Missing key in API data: {e}")
##    exit()
##
### =====================================================
### 📊 Prepare Input (ONLY features used for training)
### =====================================================
##sample = pd.DataFrame([{
##    "moisture": moisture,
##    "temperature": temperature,
##    "humidity": humidity,
##    "waterlevel": waterlevel
##}])
##
### =====================================================
### 🤖 Model Prediction
### =====================================================
##probs = model.predict_proba(sample)[0]
##sorted_indices = np.argsort(probs)[::-1]
##
##main_crop = label_encoder.inverse_transform([sorted_indices[0]])[0]
##alt_crops = label_encoder.inverse_transform(sorted_indices[1:3])
##
### =====================================================
### 🧠 Condition Analysis Function
### =====================================================
##def check_condition(value, low, high):
##    if value < low:
##        return "Low"
##    elif value > high:
##        return "High"
##    else:
##        return "Normal"
##
### Evaluate current condition status
##temp_status = check_condition(temperature, 20, 35)
##moist_status = check_condition(moisture, 40, 70)
##water_status = check_condition(waterlevel, 20, 60)
##humid_status = check_condition(humidity, 30, 80)
##d_temp_status = check_condition(d_temperature, 18, 33)
##
### =====================================================
### 📋 Print Final Report
### =====================================================
##print("\n🌾 Crop Prediction Report 🌾")
##print("-----------------------------------")
##print(f"Main Recommended Crop: {main_crop}")
##print(f"Alternative Crops: {alt_crops[0]}, {alt_crops[1]}")
##
##print("\n🧠 Environmental Condition Analysis:")
##print(f"• Temperature: {temperature}°C → {temp_status}")
##print(f"• Dallas Temperature: {d_temperature}°C → {d_temp_status}")
##print(f"• Moisture: {moisture}% → {moist_status}")
##print(f"• Humidity: {humidity}% → {humid_status}")
##print(f"• Water Level: {waterlevel} → {water_status}")
##print("-----------------------------------")
##print(f"✅ Suggestion: Based on current field and climate conditions, '{main_crop}' is best suited for cultivation.")
##print(f"🌱 Alternatively, you may consider '{alt_crops[0]}' or '{alt_crops[1]}' as secondary crop options.")



# crop_prediction_live_final.py

import requests
import joblib
import numpy as np
import pandas as pd

# =====================================================
# ⚙️ Load Model and Encoder
# =====================================================
model = joblib.load("crop_predictor.pkl")
label_encoder = joblib.load("crop_label_encoder.pkl")

# =====================================================
# 🌐 Fetch Live Data from API
# =====================================================
url = "https://aislyntech.com/Api/z-get.php"
response = requests.get(url)

if response.status_code != 200:
    print("❌ Failed to fetch data from API.")
    exit()

data = response.json()

# =====================================================
# 📦 Extract Record
# =====================================================
if "data" in data and len(data["data"]) > 0:
    record = data["data"][0]
else:
    print("⚠️ No data found in API response.")
    exit()

# =====================================================
# 🧮 Extract Features (Used for Model Training)
# =====================================================
try:
    moisture = float(record["moisture"])
    temperature = float(record["temperature"])
    humidity = float(record["humidity"])
    waterlevel = float(record["waterlevel"])

except KeyError as e:
    print(f"⚠️ Missing key in API data: {e}")
    exit()

# =====================================================
# 📊 Prepare Input (ONLY features used for training)
# =====================================================
sample = pd.DataFrame([{
    "moisture": moisture,
    "temperature": temperature,
    "humidity": humidity,
    "waterlevel": waterlevel
}])

# =====================================================
# 🤖 Model Prediction
# =====================================================
probs = model.predict_proba(sample)[0]
sorted_indices = np.argsort(probs)[::-1]

main_crop = label_encoder.inverse_transform([sorted_indices[0]])[0]
alt_crops = label_encoder.inverse_transform(sorted_indices[1:3])

# =====================================================
# 🧠 Condition Analysis Function
# =====================================================
def check_condition(value, low, high):
    if value < low:
        return "Low"
    elif value > high:
        return "High"
    else:
        return "Normal"

# Evaluate current condition status
temp_status = check_condition(temperature, 20, 35)
moist_status = check_condition(moisture, 40, 70)
water_status = check_condition(waterlevel, 20, 60)
humid_status = check_condition(humidity, 30, 80)

# =====================================================
# 📋 Print Final Report
# =====================================================
print("\n🌾 Crop Prediction Report 🌾")
print("-----------------------------------")
print(f"Main Recommended Crop: {main_crop}")
print(f"Alternative Crops: {alt_crops[0]}, {alt_crops[1]}")

print("\n🧠 Environmental Condition Analysis:")
print(f"• Temperature: {temperature}°C → {temp_status}")
print(f"• Moisture: {moisture}% → {moist_status}")
print(f"• Humidity: {humidity}% → {humid_status}")
print(f"• Water Level: {waterlevel} → {water_status}")
print("-----------------------------------")
print(f"✅ Suggestion: Based on current field and climate conditions, '{main_crop}' is best suited for cultivation.")
print(f"🌱 Alternatively, you may consider '{alt_crops[0]}' or '{alt_crops[1]}' as secondary crop options.")

